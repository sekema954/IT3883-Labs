# Final Exam.py
# Course: IT3883/section W02
# Student Name: Samuel Ekema
# Assignment Number: Final Exam
# Due Date: 05/03/2025
# Purpose: a python program that will interpret pseudo-English statements describing an amount of money in coins and convert them into a dollar amount.
""" I watched Youtube videos, used geeks.com, w3schools.com as well
    as stackoverflow to help me complete this project. I also worked on
    a similar project as this before. So it wasn't too hard
"""

# created a dictionary with coin values in dollars
coin_values = {
    "penny": 0.01,
    "nickel": 0.05,
    "dime": 0.10,
    "quarter": 0.25
}


def convert_to_dollars(sentence):
    # Her, i split the sentence by 'and' to process each coin and quantity
    words = sentence.lower().split(" and ")

    total = 0.0

    for word in words:
        parts = word.split()
        quantity = int(parts[0])
        coin = parts[1]

        if coin in coin_values:
            total += quantity * coin_values[coin]
        else:
            print(f"Unknown coin: {coin}")
            return None

    return round(total, 2)


# In this line, I Wrote code for my test cases
test_cases = [
    ("1 penny and 2 nickels", 0.11),
    ("4 dimes and 7 quarters", 2.15),
    ("1 quarter and 3 pennies", 0.28),
    ("21 pennies and 17 dimes and 52 quarters", 14.91),
    ("95 dimes and 73 quarters and 22 nickels and 36 pennies", 29.21),
    ("1 nickel and 17 quarters", 4.30),
    ("21 nickels and 15 pennies", 1.20),
    ("1 dime and 1 nickel and 1 penny and 1 quarter", 0.41)
]

# In this line, I Execute  the test cases
for sentence, expected in test_cases:
    result = convert_to_dollars(sentence)
    print(f"Input: '{sentence}' -> Output: {result} (Expected: {expected})")
